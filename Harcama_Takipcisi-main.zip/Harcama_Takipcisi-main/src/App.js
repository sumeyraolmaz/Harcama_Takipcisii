import React, { useState, useEffect, useCallback } from 'react';
import './App.css';

function App() {
    const [expenses, setExpenses] = useState([]);
    const [filteredExpenses, setFilteredExpenses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState('all');
    const [searchTerm, setSearchTerm] = useState('');
    const [sortOrder, setSortOrder] = useState('newest');
    const [dateFilter, setDateFilter] = useState('all');
    const [showStats, setShowStats] = useState(true);
    const [editing, setEditing] = useState(false);
    const [currentExpense, setCurrentExpense] = useState(null);
    const [darkMode, setDarkMode] = useState(false);

    // Form state'leri
    const [formData, setFormData] = useState({
        amount: '',
        category: '',
        description: '',
        isIncome: false
    });

    // fetchExpenses fonksiyonu
    const fetchExpenses = async () => {
        try {
            setLoading(true);
            const response = await fetch('http://localhost:5000/api/Expenses');
            if (response.ok) {
                const data = await response.json();
                setExpenses(data);
            } else {
                // Demo data for development
                const demoData = [
                    {
                        id: 1,
                        amount: 1000,
                        category: 'Market',
                        description: 'Haftalık alışveriş',
                        isIncome: false,
                        date: new Date().toISOString()
                    },
                    {
                        id: 2,
                        amount: 5000,
                        category: 'Maaş',
                        description: 'Aylık maaş',
                        isIncome: true,
                        date: new Date().toISOString()
                    }
                ];
                setExpenses(demoData);
            }
        } catch (error) {
            console.error('Veri çekme hatası:', error);
            // Demo data for offline mode
            const demoData = [
                {
                    id: 1,
                    amount: 1000,
                    category: 'Market',
                    description: 'Haftalık alışveriş',
                    isIncome: false,
                    date: new Date().toISOString()
                }
            ];
            setExpenses(demoData);
        } finally {
            setLoading(false);
        }
    };

    const filterAndSortExpenses = useCallback(() => {
        let filtered = [...expenses];

        // Kategori filtresi
        if (selectedCategory !== 'all') {
            filtered = filtered.filter(expense =>
                expense.category.toLowerCase() === selectedCategory.toLowerCase()
            );
        }

        // Arama filtresi
        if (searchTerm) {
            filtered = filtered.filter(expense =>
                expense.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                expense.description.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        // Tarih filtresi
        if (dateFilter !== 'all') {
            const today = new Date();
            const filterDate = new Date();

            switch (dateFilter) {
                case 'today':
                    filterDate.setHours(0, 0, 0, 0);
                    filtered = filtered.filter(expense => new Date(expense.date) >= filterDate);
                    break;
                case 'week':
                    filterDate.setDate(today.getDate() - 7);
                    filtered = filtered.filter(expense => new Date(expense.date) >= filterDate);
                    break;
                case 'month':
                    filterDate.setMonth(today.getMonth() - 1);
                    filtered = filtered.filter(expense => new Date(expense.date) >= filterDate);
                    break;
                default:
                    break;
            }
        }

        // Sıralama - HATA DÜZELTİLDİ
        filtered.sort((a, b) => {
            const dateA = new Date(a.date);
            const dateB = new Date(b.date);

            if (sortOrder === 'amount-high') return b.amount - a.amount;
            if (sortOrder === 'amount-low') return a.amount - b.amount;
            return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
        });

        setFilteredExpenses(filtered);
    }, [expenses, selectedCategory, searchTerm, sortOrder, dateFilter]);

    useEffect(() => {
        fetchExpenses();
    }, []);

    useEffect(() => {
        filterAndSortExpenses();
    }, [filterAndSortExpenses]);

    useEffect(() => {
        document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
    }, [darkMode]);

    const handleEdit = (expense) => {
        setEditing(true);
        setCurrentExpense(expense);
        setFormData({
            amount: expense.amount,
            category: expense.category,
            description: expense.description,
            isIncome: expense.isIncome
        });
        setShowForm(true);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (editing) {
                // Güncelleme isteği
                const response = await fetch(`http://localhost:5000/api/Expenses/${currentExpense.id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        ...formData,
                        amount: parseFloat(formData.amount),
                        date: currentExpense.date
                    })
                });

                if (response.ok) {
                    setEditing(false);
                    setCurrentExpense(null);
                    fetchExpenses();
                }
            } else {
                // Yeni ekleme isteği
                const response = await fetch('http://localhost:5000/api/Expenses', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        ...formData,
                        amount: parseFloat(formData.amount),
                        date: new Date().toISOString()
                    })
                });

                if (response.ok) {
                    fetchExpenses();
                }
            }

            setFormData({ amount: '', category: '', description: '', isIncome: false });
            setShowForm(false);
        } catch (error) {
            console.error('Hata:', error);
            // Demo mode için local işlemler
            if (editing) {
                setExpenses(prev => prev.map(exp =>
                    exp.id === currentExpense.id ?
                        { ...exp, ...formData, amount: parseFloat(formData.amount) } :
                        exp
                ));
            } else {
                const newExpense = {
                    id: Date.now(),
                    ...formData,
                    amount: parseFloat(formData.amount),
                    date: new Date().toISOString()
                };
                setExpenses(prev => [newExpense, ...prev]);
            }

            setFormData({ amount: '', category: '', description: '', isIncome: false });
            setShowForm(false);
            setEditing(false);
            setCurrentExpense(null);
        }
    };

    const handleCancel = () => {
        setShowForm(false);
        setEditing(false);
        setCurrentExpense(null);
        setFormData({ amount: '', category: '', description: '', isIncome: false });
    };

    const deleteExpense = async (id) => {
        try {
            const response = await fetch(`http://localhost:5000/api/Expenses/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                fetchExpenses();
            }
        } catch (error) {
            console.error('Silme hatası:', error);
            // Demo mode için local silme
            setExpenses(prev => prev.filter(expense => expense.id !== id));
        }
    };

    const handleInputChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const toggleTheme = () => {
        setDarkMode(!darkMode);
    };

    // İstatistikler hesapla
    const totalIncome = expenses.filter(e => e.isIncome).reduce((sum, e) => sum + e.amount, 0);
    const totalExpense = expenses.filter(e => !e.isIncome).reduce((sum, e) => sum + e.amount, 0);
    const balance = totalIncome - totalExpense;

    // Kategori istatistikleri
    const categoryStats = expenses.reduce((acc, expense) => {
        if (!expense.isIncome) {
            acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
        }
        return acc;
    }, {});

    const topCategories = Object.entries(categoryStats)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 3);

    // Benzersiz kategorileri al
    const categories = [...new Set(expenses.map(e => e.category))];

    // Kategori emojileri
    const categoryEmojis = {
        'Market': '🛒',
        'Maaş': '💰',
        'Ulaşım': '🚗',
        'Eğlence': '🎬',
        'Kahve': '☕',
        'Yemek': '🍽️',
        'Alışveriş': '🛍️',
        'Sağlık': '🏥',
        'Eğitim': '📚',
        'Kira': '🏠',
        'Fatura': '🧾',
        'Spor': '⚽',
        'Teknoloji': '💻',
        'Giyim': '👕'
    };

    if (loading) {
        return (
            <div className="loading-container">
                <div className="loading-spinner"></div>
                <p>Yükleniyor...</p>
            </div>
        );
    }

    return (
        <div className="App">
            {/* Header */}
            <div className="header-section">
                <h1>💖 Harcama Takipçim</h1>
                <p className="subtitle">Finanslarını pembe gözlükle takip et ✨</p>
            </div>

            {/* Tema Değiştirme Butonu */}
            <div className="theme-toggle">
                <button className="toggle-btn" onClick={toggleTheme}>
                    {darkMode ? '☀️' : '🌙'}
                </button>
            </div>

            {/* Stats Toggle */}
            <div className="stats-toggle">
                <button
                    className={`toggle-stats-btn ${showStats ? 'active' : ''}`}
                    onClick={() => setShowStats(!showStats)}
                >
                    <i>{showStats ? '📊' : '📈'}</i>
                    {showStats ? 'İstatistikleri Gizle' : 'İstatistikleri Göster'}
                    {!showStats && <span className="pulse-dot"></span>}
                </button>
            </div>

            {/* İstatistik Kartları */}
            {showStats && (
                <div className="stats-container">
                    <div className="stat-card income-card">
                        <div className="stat-header">
                            <span className="stat-icon">📈</span>
                            <h3>Toplam Gelir</h3>
                        </div>
                        <p className="stat-amount income">+{totalIncome.toFixed(2)} ₺</p>
                    </div>

                    <div className="stat-card expense-card">
                        <div className="stat-header">
                            <span className="stat-icon">📉</span>
                            <h3>Toplam Gider</h3>
                        </div>
                        <p className="stat-amount expense">-{totalExpense.toFixed(2)} ₺</p>
                    </div>

                    <div className={`stat-card balance-card ${balance >= 0 ? 'positive' : 'negative'}`}>
                        <div className="stat-header">
                            <span className="stat-icon">💎</span>
                            <h3>Net Bakiye</h3>
                        </div>
                        <p className="stat-amount">{balance >= 0 ? '+' : ''}{balance.toFixed(2)} ₺</p>
                    </div>

                    {/* En Çok Harcanan Kategoriler */}
                    {topCategories.length > 0 && (
                        <div className="top-categories-card">
                            <h3>🔥 En Çok Harcanan Kategoriler</h3>
                            <div className="top-categories-list">
                                {topCategories.map(([category, amount]) => (
                                    <div key={category} className="top-category-item">
                                        <span className="category-emoji">
                                            {categoryEmojis[category] || '📦'}
                                        </span>
                                        <div className="category-details">
                                            <div className="category-name">{category}</div>
                                            <div className="category-amount">{amount.toFixed(2)} ₺</div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* Kontrol Paneli */}
            <div className="controls-section">
                <div className="controls-grid">
                    <button
                        className={`control-btn add-btn ${showForm ? 'cancel' : ''}`}
                        onClick={() => setShowForm(!showForm)}
                    >
                        {showForm ? '❌ İptal Et' : '➕ Yeni Kayıt'}
                    </button>

                    <div className="search-container">
                        <input
                            type="text"
                            placeholder="🔍 Ara..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="search-input"
                        />
                    </div>

                    <select
                        value={sortOrder}
                        onChange={(e) => setSortOrder(e.target.value)}
                        className="control-select"
                    >
                        <option value="newest">📅 En Yeni</option>
                        <option value="oldest">📅 En Eski</option>
                        <option value="amount-high">💰 Yüksek Tutar</option>
                        <option value="amount-low">💰 Düşük Tutar</option>
                    </select>

                    <select
                        value={dateFilter}
                        onChange={(e) => setDateFilter(e.target.value)}
                        className="control-select"
                    >
                        <option value="all">🗓️ Tüm Zamanlar</option>
                        <option value="today">🗓️ Bugün</option>
                        <option value="week">🗓️ Son 7 Gün</option>
                        <option value="month">🗓️ Son 30 Gün</option>
                    </select>
                </div>
            </div>

            {/* Kategori Filtreleri */}
            <div className="filter-container">
                <button
                    className={`filter-btn ${selectedCategory === 'all' ? 'active' : ''}`}
                    onClick={() => setSelectedCategory('all')}
                >
                    🔄 Tümü ({expenses.length})
                </button>

                {categories.map(category => (
                    <button
                        key={category}
                        className={`filter-btn ${selectedCategory === category ? 'active' : ''}`}
                        onClick={() => setSelectedCategory(category)}
                    >
                        {categoryEmojis[category] || '📦'} {category} ({expenses.filter(e => e.category === category).length})
                    </button>
                ))}
            </div>

            {/* Form */}
            {showForm && (
                <div className="expense-form-container">
                    <form className="expense-form" onSubmit={handleSubmit}>
                        <h3 className="form-title">
                            {editing ? '✏️ Kaydı Düzenle' : '✨ Yeni Kayıt Ekle'}
                        </h3>

                        <div className="form-row">
                            <input
                                type="number"
                                name="amount"
                                placeholder="💰 Tutar (₺)"
                                value={formData.amount}
                                onChange={handleInputChange}
                                required
                                step="0.01"
                                className="form-input"
                            />

                            <input
                                type="text"
                                name="category"
                                placeholder="📂 Kategori"
                                value={formData.category}
                                onChange={handleInputChange}
                                required
                                className="form-input"
                            />
                        </div>

                        <input
                            type="text"
                            name="description"
                            placeholder="📝 Açıklama"
                            value={formData.description}
                            onChange={handleInputChange}
                            required
                            className="form-input full-width"
                        />

                        <div className="form-footer">
                            <div>
                                <button
                                    type="button"
                                    className="cancel-button"
                                    onClick={handleCancel}
                                >
                                    İptal
                                </button>
                            </div>
                            <div>
                                <label className="checkbox-label">
                                    <input
                                        type="checkbox"
                                        name="isIncome"
                                        checked={formData.isIncome}
                                        onChange={handleInputChange}
                                        className="form-checkbox"
                                    />
                                    <span className="checkmark"></span>
                                    💸 Bu bir gelir
                                </label>
                            </div>
                            <button type="submit" className="submit-button">
                                {editing ? '💾 Güncelle' : '🚀 Kaydet'}
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {/* Sonuç sayısı */}
            <div className="results-info">
                <p>📊 {filteredExpenses.length} kayıt görüntüleniyor</p>
            </div>

            {/* Harcama Listesi */}
            <div className="expenses-list">
                {filteredExpenses.length === 0 ? (
                    <div className="no-results">
                        <div className="no-results-icon">🔍</div>
                        <p>Aradığınız kriterlerde kayıt bulunamadı</p>
                    </div>
                ) : (
                    filteredExpenses.map(expense => (
                        <div key={expense.id} className={`expense-card ${expense.isIncome ? 'income-type' : 'expense-type'}`}>
                            <div className="card-header">
                                <div className="card-title-section">
                                    <span className="category-emoji">
                                        {categoryEmojis[expense.category] || '📦'}
                                    </span>
                                    <div className="card-title-content">
                                        <h3 className="card-category">{expense.category}</h3>
                                        <span className="card-type">
                                            {expense.isIncome ? '💰 Gelir' : '💸 Gider'}
                                        </span>
                                    </div>
                                </div>
                                <div className="card-actions">
                                    <button
                                        className="edit-button"
                                        onClick={() => handleEdit(expense)}
                                        title="Düzenle"
                                    >
                                        ✏️
                                    </button>
                                    <button
                                        className="delete-button"
                                        onClick={() => deleteExpense(expense.id)}
                                        title="Sil"
                                    >
                                        ❌
                                    </button>
                                </div>
                            </div>

                            <p className="card-description">📝 {expense.description}</p>

                            <div className="card-footer">
                                <p className={`card-amount ${expense.isIncome ? 'income' : 'expense'}`}>
                                    {expense.isIncome ? '+' : '-'}{expense.amount.toFixed(2)} ₺
                                </p>
                                <small className="card-date">
                                    📅 {new Date(expense.date).toLocaleDateString('tr-TR', {
                                        day: '2-digit',
                                        month: '2-digit',
                                        year: 'numeric',
                                        hour: '2-digit',
                                        minute: '2-digit'
                                    })}
                                </small>
                            </div>
                        </div>
                    ))
                )}
            </div>

            {/* Footer */}
            <div className="footer">
                <p>💖 Pembe tonlarında tasarlanmıştır • React ile geliştirilmiştir ✨</p>
            </div>
        </div>
    );
}

export default App;
